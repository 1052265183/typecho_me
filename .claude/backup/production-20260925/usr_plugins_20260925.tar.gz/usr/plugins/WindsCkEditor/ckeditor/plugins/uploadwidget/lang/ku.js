﻿/**
 * @license Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'ku', {
	abort: 'بارکردنەکە بڕدرا لەلایەن بەکارهێنەر.',
	doneOne: 'پەڕگەکە بەسەرکەوتووانە بارکرا.',
	doneMany: 'بەسەرکەوتووانە بارکرا %1 پەڕگە.',
	uploadOne: 'پەڕگە باردەکرێت ({percentage}%)...',
	uploadMany: 'پەڕگە باردەکرێت, {current} لە {max} ئەنجامدراوە ({percentage}%)...'
} );
