﻿/**
 * @license Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 * For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
 */

CKEDITOR.plugins.setLang( 'uploadwidget', 'eo', {
	abort: 'Alŝuto ĉesigita de la uzanto',
	doneOne: 'Dosiero sukcese alŝutita.',
	doneMany: 'Sukcese alŝutitaj %1 dosieroj.',
	uploadOne: 'alŝutata dosiero ({percentage}%)...',
	uploadMany: 'Alŝutataj dosieroj, {current} el {max} faritaj ({percentage}%)...'
} );
