﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pagebreak', 'en', {
	alt: 'Page Break',
	toolbar: 'Insert Page Break for Printing'
} );
