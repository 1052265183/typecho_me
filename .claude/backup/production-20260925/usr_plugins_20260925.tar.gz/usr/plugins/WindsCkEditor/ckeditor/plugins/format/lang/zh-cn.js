﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'format', 'zh-cn', {
	label: '格式',
	panelTitle: '格式',
	tag_address: '地址',
	tag_div: '段落(DIV)',
	tag_h1: '标题 1',
	tag_h2: '标题 2',
	tag_h3: '标题 3',
	tag_h4: '标题 4',
	tag_h5: '标题 5',
	tag_h6: '标题 6',
	tag_p: '普通',
	tag_pre: '已编排格式'
} );
