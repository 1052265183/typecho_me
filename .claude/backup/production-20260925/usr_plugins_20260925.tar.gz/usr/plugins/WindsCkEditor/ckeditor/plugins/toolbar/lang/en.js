﻿/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'en', {
	toolbarCollapse: 'Collapse Toolbar',
	toolbarExpand: 'Expand Toolbar',
	toolbarGroups: {
		document: 'Document',
		clipboard: 'Clipboard/Undo',
		editing: 'Editing',
		forms: 'Forms',
		basicstyles: 'Basic Styles',
		paragraph: 'Paragraph',
		links: 'Links',
		insert: 'Insert',
		styles: 'Styles',
		colors: 'Colors',
		tools: 'Tools'
	},
	toolbars: 'Editor toolbars'
} );
